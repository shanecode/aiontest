package instance.Ascension;

import com.aionemu.gameserver.instance.handlers.GeneralInstanceHandler;
import com.aionemu.gameserver.instance.handlers.InstanceID;

/**
 * @author Dean
 */
@InstanceID(0)
public class RentusBaseInstance extends GeneralInstanceHandler {

}