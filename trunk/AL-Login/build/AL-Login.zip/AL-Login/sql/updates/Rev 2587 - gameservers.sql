INSERT INTO `gameservers` (`id`, `mask`, `password`) VALUES
(1, '*', '12345');