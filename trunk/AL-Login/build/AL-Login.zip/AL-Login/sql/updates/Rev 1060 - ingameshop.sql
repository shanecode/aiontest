ALTER TABLE `account_data`
ADD COLUMN `toll`  int(11) NOT NULL DEFAULT '0' AFTER `ip_force`;